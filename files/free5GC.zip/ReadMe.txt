* This package contains the executable binary files of free5GC AMF, SMF, and NRF. 
* All files only run on Linux system with kernel version higher than 5.0.0-23. (Note that all series of Windows system are not available)

Execution method:

In the command-line of Linux, type:
$ ./nrf.exe
$ ./smf.exe
$ ./amf.exe